﻿using AutoMapper;
using DataAccess.DTOs;
using DataAccess.TSModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INextAdminApp.Helper
{
    public class AutoMapperProfiles : Profile
    {
        public AutoMapperProfiles()
        {
            CreateMap<TSTblClient, ClientDTO>();
            
        }
    }
}
