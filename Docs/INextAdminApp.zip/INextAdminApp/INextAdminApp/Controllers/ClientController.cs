﻿using BusinessLayer;
using DataAccess.DTOs;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INextAdminApp.Controllers
{
    [Route("api/client")]
    [ApiController]
    public class ClientController : ControllerBase
    {
        private readonly IClientService _clientService;

        public ClientController(IClientService clientService, IWebHostEnvironment webHostEnvironment)
        {
            _clientService = clientService;
        }

        [HttpGet("client")]
        [ApiExplorerSettings(IgnoreApi = true)]
        public async Task<IActionResult> GetAllClients()
        {
            return Ok(await _clientService.GetAllClients());
        }

        /// <summary>
        /// Add a client 
        /// </summary>
        /// <param name="contact"></param>
        /// <returns></returns>
        [HttpPost("client")]
        public async Task<IActionResult> AddOrUpdateClient([FromBody] ClientDTO client)
        {
            return Ok(await _clientService.AddOrUpdateClient(client));
        }

        /// <summary>
        /// Delete a client from list
        /// </summary>
        [HttpDelete("client")]
        public async Task<IActionResult> Delete()
        {
            var queryString = HttpContext.Request.QueryString;
            var queryStringCollection = System.Web.HttpUtility.ParseQueryString(queryString.Value);
            var id = queryStringCollection.Get("id");
            
            if (string.IsNullOrEmpty(id))
                return BadRequest();
            await _clientService.DeleteClient(id);
            return Ok();
        }

    }
}
