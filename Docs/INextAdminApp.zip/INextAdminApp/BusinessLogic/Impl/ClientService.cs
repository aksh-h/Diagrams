﻿using AutoMapper;
using AutoMapper.Configuration;
using BusinessLogic.Common;
using DataAccess.DTOs;
using DataAccess.Repositories;
using DataAccess.TSModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Impl
{
    public class ClientService : IClientService
    {
        private readonly IUnitOfWork _tsUnitOfWork;
        private readonly IConfiguration _configuration;
        private readonly DbConfig _dbConfig;
        private readonly IMapper _mapper;

        public ClientService(IConfiguration configuration, DbConfig dbConfig, IMapper mapper, IUnitOfWork tSUnitOfWork)
        {
            _tsUnitOfWork = tSUnitOfWork;
            _configuration = configuration;
            _dbConfig = dbConfig;
            _mapper = mapper;
        }

        public async Task<IEnumerable<ClientDTO>> GetAllClients()
        {
            //  fetch all clients from repo
            return _mapper.Map<ClientDTO[]>(await _tsUnitOfWork.ClientRepository.GetAllAsync());
        }

        public async Task<ClientDTO> AddOrUpdateClient(ClientDTO client)
        {
            var tblclient = _mapper.Map<TSTblClient>(client);
            var result = await _tsUnitOfWork.ClientRepository.AddOrUpdateAsync(tblclient);
            return _mapper.Map<ClientDTO>(result);
        }

        public async Task DeleteClient(string Id)
        {
            var result = await _tsUnitOfWork.ClientRepository.QueryAsync($"Company eq '{Id}'");//($"PartitionKey eq '{userId}'");

            if (result != default && result.Any())
                //  delete the  record
                _tsUnitOfWork.ClientRepository.DeleteAsync(result.FirstOrDefault());
        }
    }
}
