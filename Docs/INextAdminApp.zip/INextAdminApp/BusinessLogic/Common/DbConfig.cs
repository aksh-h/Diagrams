﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Common
{
    public class DbConfig
    {
        /// <summary>  
        /// This dictionary will hold a record for config data.   
        /// </summary>  
        public Dictionary<string, string> ConfigItems = new Dictionary<string, string>();
    }
}
