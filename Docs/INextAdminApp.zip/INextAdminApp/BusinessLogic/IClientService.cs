﻿using DataAccess.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public interface IClientService
    {
        //Task<ClientDTO> GetClient(string clientId);

        Task<IEnumerable<ClientDTO>> GetAllClients();

        Task<ClientDTO> AddOrUpdateClient(ClientDTO client);

        Task DeleteClient(string Id);

    }
}
