﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Models
{
    public class TableStorageDBContext
    {
        public TableStorageDBContext(string connectionString, string identityConnectionString)
        {
            ConnectionString = connectionString;
            //IdentityConnectionString = identityConnectionString;
        }

        public static string ConnectionString
        {
            get;
            set;
        }
        public static string IdentityConnectionString
        {
            get;
            set;
        }

        //public static string TempBlobURLString
        //{
        //    get;
        //    set;
        //}

    }
}
