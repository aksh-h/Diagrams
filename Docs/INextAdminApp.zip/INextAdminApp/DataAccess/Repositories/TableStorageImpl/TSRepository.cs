﻿using Microsoft.Azure.Cosmos.Table;
using System.Linq;
using System.Threading.Tasks;

namespace DataAccess.Repositories.Impl
{
    public class TSRepository<T> : ITSRepository<T> where T : class, ITableEntity, new()
    {
        private readonly CloudTable _table;

        public TSRepository(string tableName, string connectionString)
        {
            var storageAccountDetails = CloudStorageAccount.Parse(connectionString);//CloudStorageAccount.Parse(TableStorageDBContext.ConnectionString);
            CloudTableClient tblclient = storageAccountDetails.CreateCloudTableClient(new TableClientConfiguration());
            _table = tblclient.GetTableReference(tableName);
        }

        public async Task<IQueryable<T>> GetAllAsync()
        {
            return await Task.Run(() => _table.ExecuteQuery(new TableQuery<T>()).AsQueryable());
        }

        public async Task<IQueryable<T>> QueryAsync(string expression)
        {
            return await Task.Run(() => _table.ExecuteQuery(new TableQuery<T> { FilterString = expression }).AsQueryable());
        }

        public async Task<T> FindAsync(string rowKey, string partitionKey)
        {
            var entity = await _table.ExecuteAsync(TableOperation.Retrieve<T>(partitionKey, rowKey));
            return entity.Result as T;
        }

        public async Task<T> AddOrUpdateAsync(T record)
        {
            TableOperation insertOperation = TableOperation.InsertOrMerge(record);
            var entity = await _table.ExecuteAsync(insertOperation);
            return entity.Result as T;
        }

        public async void DeleteAsync(T record)
        {
            await _table.ExecuteAsync(TableOperation.Delete(record));
        }
    }
}
