﻿using AutoMapper;
using AutoMapper.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repositories.TableStorageImpl
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;
        private ITSClientRepository _clientRepository;

        public UnitOfWork(IMapper mapper, IConfiguration configuration)
        {
            _mapper = mapper;
            _configuration = configuration;
        }


        public ITSClientRepository ClientRepository
        {
            get
            {
                return _clientRepository ??= new TSClientRepository(_mapper);
            }
        }
    }
}
