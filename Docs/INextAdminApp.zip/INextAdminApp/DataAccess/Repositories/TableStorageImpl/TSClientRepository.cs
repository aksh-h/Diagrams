﻿using AutoMapper;
using DataAccess.Models;
using DataAccess.Repositories.Impl;
using DataAccess.TSModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Repositories.TableStorageImpl
{
    public class TSClientRepository : TSRepository<TSTblClient>,ITSClientRepository
    {
        private readonly IMapper _mapper;
        public TSClientRepository(IMapper mapper) : base("tblClients", TableStorageDBContext.ConnectionString)
        {
            _mapper = mapper;
        }
    }
}
