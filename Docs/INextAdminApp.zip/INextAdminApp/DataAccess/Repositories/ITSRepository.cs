﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public interface ITSRepository<T> where T : class
    {
        public Task<IQueryable<T>> GetAllAsync();

        public Task<T> FindAsync(string rowKey, string partitionKey);

        public Task<T> AddOrUpdateAsync(T t);

        public void DeleteAsync(T t);

        public Task<IQueryable<T>> QueryAsync(string expression);

    }
}
