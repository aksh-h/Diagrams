﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.DTOs
{
    public class ClientDTO
    {
        public Guid Id { get; set; }
        public string Company { get; set; }
        public string Company_Logo { get; set; }
        public string Main_Contact { get; set; }
        public string Main_Contact_Email { get; set; }
        public string Main_Contact_Phone { get; set; }
        public string OnBoarded_Date { get; set; }
        public string Reg_Address { get; set; }
        public string Reg_City { get; set; }
        public string Reg_Country { get; set; }
        public string Reg_Name { get; set; }
        public string Website { get; set; }
    }
}
