﻿using Microsoft.Azure.Cosmos.Table;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.TSModels
{
    public class TSTblClient : TableEntity
    {
        public TSTblClient()
        { }

        public TSTblClient(string partitionKey, string rowKey)
        {
            PartitionKey = partitionKey;
            RowKey = rowKey;
        }

        public Guid Id { get => Guid.Parse(RowKey); set => RowKey = value.ToString(); }
        public string Company { get => PartitionKey; set { PartitionKey = value; } }
        public string Company_Logo { get; set; }
        public string Main_Contact { get; set; }
        public string Main_Contact_Email { get; set; }
        public string Main_Contact_Phone { get; set; }
        public string OnBoarded_Date { get; set; }
        public string Reg_Address { get; set; }
        public string Reg_City { get; set; }
        public string Reg_Country { get; set; }
        public string Reg_Name { get; set; }
        public string Reg_State { get; set; }
        public string Website { get; set; }
        
    }
}
